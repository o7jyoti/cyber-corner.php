<?php
// Database Connection Function
function getDbConnection() {
    $servername = "localhost";
    $username = "root"; // Replace with your database username
    $password = ""; // Replace with your database password
    $dbname = "login_register"; // Replace with your database name
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

// Check if the request is valid
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    // Sanitize and validate input
    $productId = intval($_POST['product_id']);

    // Establish database connection
    $conn = getDbConnection();

    // Use a prepared statement to securely delete the product
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $productId);

    // Execute the statement and check the result
    if ($stmt->execute()) {
        echo "Product deleted successfully!";
    } else {
        echo "Error deleting product: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();

    // Redirect back to admin dashboard
    header("Location: admin_dashboard.php");
    exit;
} else {
    echo "Invalid request.";
    exit;
}
?>
