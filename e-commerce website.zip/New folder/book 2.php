<!DOCTYPE html>
<html lang="en">
<head>
    <title>Booking</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="book">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
    <link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
    <link rel="stylesheet" href="plugins/themify-icons/themify-icons.css">
    <link rel="stylesheet" type="text/css" href="plugins/jquery-ui-1.12.1.custom/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="styles/contact_styles.css">
    <link rel="stylesheet" type="text/css" href="styles/contact_responsive.css">
    <link rel="stylesheet" type="text/css" href="styles/main_styles.css">
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
        }

        h2 {
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: bold;
        }

        button {
            font-size: 16px;
            padding: 10px 20px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
        }

        button.btn-primary {
            background-color: #007bff;
            color: #fff;
        }

        button.btn-primary:hover {
            background-color: #0056b3;
        }

        button.btn-success {
            background-color: #28a745;
            color: #fff;
        }

        button.btn-success:hover {
            background-color: #218838;
        }

        /* Cart Section Styles */
        .cart-items-container {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
            background-color: #f8f9fa;
        }

        .cart-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .order-summary {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            background-color: #f8f9fa;
        }

        .order-summary h4 {
            font-size: 20px;
            margin-bottom: 10px;
        }

        .product-price, .total-price {
            font-size: 18px;
        }

        .total-price strong {
            color: #333;
        }

        /* Booking Section Styles */
        #booking1 {
            border: 1px solid #ddd;
            border-radius: 8px;
            background: #f8f9fa;
            padding: 20px;
        }

        form#bookingForm .form-group {
            margin-bottom: 15px;
        }

        form#bookingForm label {
            font-weight: bold;
        }

        form#bookingForm input,
        form#bookingForm textarea {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-top: 5px;
        }

        form#bookingForm textarea {
            resize: none;
        }

        form#bookingForm input:focus,
        form#bookingForm textarea:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .cart-items-container, .order-summary, #booking1 {
                padding: 10px;
            }

            button {
                font-size: 14px;
                padding: 