<!DOCTYPE html>
<html lang="en">
<head>
    <title>Single Product</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Colo Shop Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <style>
        /* Styles from external CSS files (bootstrap, font-awesome, etc.) */
        body {
            font-family: Arial, sans-serif;
        }

        .super_container {
            padding: 20px;
        }

        /* Add other styles here like from bootstrap4/bootstrap.min.css, single_styles.css, etc. */
        
        .hamburger_menu .hamburger_close {
            font-size: 30px;
        }

        /* Specific styles for your layout */
        .product_details_title h2 {
            font-size: 2rem;
            margin: 10px 0;
        }

        .product_price {
            font-size: 1.5rem;
            color: red;
        }

        .red_button {
            background-color: red;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
        }

        /* Add other CSS from your stylesheets */
    </style>
</head>

<body>
    <div class="super_container">
        <!-- Header -->
        <div class="hamburger_menu">
            <div class="hamburger_close"><i class="fa fa-times" aria-hidden="true"></i></div>
            <div class="hamburger_menu_content text-right">
                <ul class="menu_top_nav">
                    <li class="menu_item has-children">
                        <a href="#">USD <i class="fa fa-angle-down"></i></a>
                        <ul class="menu_selection">
                            <li><a href="#">CAD</a></li>
                            <li><a href="#">AUD</a></li>
                            <li><a href="#">EUR</a></li>
                            <li><a href="#">GBP</a></li>
                        </ul>
                    </li>
                    <li class="menu_item"><a href="#">Home</a></li>
                    <li class="menu_item"><a href="#">Shop</a></li>
                    <li class="menu_item"><a href="#">Blog</a></li>
                    <li class="menu_item"><a href="#">Contact</a></li>
                </ul>
            </div>
        </div>

        <!-- Product Details Section -->
        <div class="container single_product_container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="single_product_pics">
                        <div class="row">
                            <div class="col-lg-3 thumbnails_col">
                                <div class="single_product_thumbnails">
                                    <ul>
                                        <li><img src="images/single_1_thumb.jpg" alt="" data-image="images/single_1.jpg"></li>
                                        <li class="active"><img src="images/single_2_thumb.jpg" alt="" data-image="images/single_2.jpg"></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-9 image_col">
                                <div class="single_product_image">
                                    <div class="single_product_image_background" style="background-image:url(images/single_2.jpg)"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-5">
                    <div class="product_details">
                        <div class="product_details_title">
                            <h2>Pocket Cotton Sweatshirt</h2>
                            <p>Nam tempus turpis at metus scelerisque placerat nulla deumantos solicitud felis...</p>
                        </div>
                        <div class="free_delivery d-flex flex-row align-items-center justify-content-center">
                            <span class="ti-truck"></span><span>Free Delivery</span>
                        </div>
                        <div class="original_price">$629.99</div>
                        <div class="product_price">$495.00</div>
                        <ul class="star_rating">
                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                            <li><i class="fa fa-star" aria-hidden="true"></i></li>
                            <li><i class="fa fa-star-o" aria-hidden="true"></i></li>
                        </ul>
                        <div class="product_color">
                            <span>Select Color:</span>
                            <ul>
                                <li style="background: #e54e5d"></li>
                                <li style="background: #252525"></li>
                                <li style="background: #60b3f3"></li>
                            </ul>
                        </div>
                        <div class="quantity d-flex flex-column flex-sm-row align-items-sm-center">
                            <span>Quantity:</span>
                            <div class="quantity_selector">
                                <span class="minus"><i class="fa fa-minus" aria-hidden="true"></i></span>
                                <span id="quantity_value">1</span>
                                <span class="plus"><i class="fa fa-plus" aria-hidden="true"></i></span>
                            </div>
                            <div class="red_button add_to_cart_button"><a href="#">Add to Cart</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabs Section -->
        <div class="tabs_section_container">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="tabs_container">
                            <ul class="tabs d-flex flex-sm-row flex-column align-items-left align-items-md-center justify-content-center">
                                <li class="tab active" data-active-tab="tab_1"><span>Description</span></li>
                                <li class="tab" data-active-tab="tab_2"><span>Additional Information</span></li>
                                <li class="tab" data-active-tab="tab_3"><span>Reviews (2)</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <!-- Tab Content -->
                        <div id="tab_1" class="tab_container active">
                            <div class="tab_title">
                                <h4>Description</h4>
                            </div>
                            <p>Pocket cotton sweatshirt with a modern design for casual wear. Made with premium cotton...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Section -->
        <footer>
            <div class="container">
                <p>&copy; 2024 Colo Shop. All Rights Reserved.</p>
            </div>
        </footer>
    </div>

    <!-- JavaScript Files -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="styles/bootstrap4/popper.js"></script>
    <script src="styles/bootstrap4/bootstrap.min.js"></script>
    <script src="plugins/Isotope/isotope.pkgd.min.js"></script>
    <script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
    <script src="plugins/easing/easing.js"></script>
    <script src="plugins/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
    <script src="js/single_custom.js"></script>
</body>
</html>
