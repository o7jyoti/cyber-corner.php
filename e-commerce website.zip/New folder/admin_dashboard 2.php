<?php

$hostName = "localhost";
$dbUser = "root";
$dbPassword = ""; // Typically empty in XAMPP
$dbName = "login_register";

// Function to create a database connection
function getDbConnection() {
    global $hostName, $dbUser, $dbPassword, $dbName;
    $conn = mysqli_connect($hostName, $dbUser, $dbPassword, $dbName);

    // Check if the connection is successful
    if (!$conn) {
        error_log("Database connection failed: " . mysqli_connect_error());
        die("An internal error occurred. Please try again later.");
    }
    return $conn;
}

?>
